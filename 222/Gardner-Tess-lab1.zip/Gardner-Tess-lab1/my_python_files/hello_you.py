name = input("What's your name? ")
print(f"Hey {name}")
age = input("What's your age? ")
age = int(age)
print(f"Half of your age is {age/2}")

